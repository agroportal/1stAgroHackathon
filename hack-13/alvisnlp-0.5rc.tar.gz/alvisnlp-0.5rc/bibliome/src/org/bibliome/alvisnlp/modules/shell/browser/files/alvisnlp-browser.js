/*
Copyright 2016 Institut National de la Recherche Agronomique

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

var THEME = 'fresh';

var createSections = function() {
	var container = $('#tree-container');

	var windowId = 'sections-window';
	container.append('<div id="'+windowId+'"></div>');
	var window = $('#'+windowId);
	window.jqxPanel({
		theme: THEME,
		width: 600,
		height: 600
	});

	var closeId = 'sections-close';
	window.jqxPanel('append', $('<button id="sections-close">Close</button>'));
	var close = $('#'+closeId);
	close.jqxButton({
		theme: THEME
	});
	close.on('click', function(event) {
		$('#'+windowId).jqxPanel('destroy');
	});
	
	var sectionsContainerId = 'sections-container';
	window.jqxPanel('append', $('<div id="'+sectionsContainerId+'"></div>'));
	var sectionsContainer = $('#'+sectionsContainerId);
	
	var prevTreeNum = openedTrees[0];
	$.ajax({
		url: '/sections?node='+$('#tree-'+prevTreeNum).jqxTree('val').value,
		success: function(data, status, xhr) {
			console.log(data);
			if (data.success) {
				for (var i = 0; i < data.result.length; ++i) {
					var sec = data.result[i];
					sectionsContainer.append('<div class="section-name">'+sec.name+'</div>');
					sectionsContainer.append(sec.contents);
				}
			}
		}
	});
}

var nextTreeNum = 0;
var openedTrees = [];

var createTree = function() {
	var mainTree = (openedTrees.length == 0);
	var treeNum = nextTreeNum;
	nextTreeNum++;
	openedTrees.unshift(treeNum);
	
	var container = $('#tree-container');
	
	var windowId = 'tree-window-' + treeNum;
	container.append('<div class="tree-window" id="'+windowId+'"></div>');
	var window = $('#'+windowId);
	window.jqxPanel({
		theme: THEME,
		width: 300,
		height: 600
	});

	var expressionBoxId = 'tree-expression-box-' + treeNum;
	window.jqxPanel('append', $('<input class="tree-expression-box" id="'+expressionBoxId+'"></div>'));
	var expressionBox = $('#'+expressionBoxId);

	var closeId = 'tree-close-' + treeNum;
	window.jqxPanel('append', $('<button class="tree-close" id="'+closeId+'">Close</button>'));
	var close = $('#'+closeId);
	close.jqxButton({
		theme: THEME
	})
	
	if (!mainTree) {
		expressionBox.jqxInput({
			theme: THEME,
			width: 240,
			height: 20,
			placeHolder: 'Expression'
		});
		expressionBox.on('change', function(event) {
			updateTree(treeNum);
		});
		$('#tree-'+openedTrees[1]).on('select', function(event) {
			updateTree(treeNum);
		});
		close.on('click', function(event) {
			while (true) {
				var t = openedTrees.shift();
				$('#tree-window-'+t).jqxPanel('destroy');
				if (t == treeNum) {
					break;
				}
			}
		});
		expressionBox.css({ visibility: 'visible' });
		close.css({ visibility: 'visible' });
	}
	
	if (mainTree) {
		$.ajax({
			url: '/corpus?treenum='+treeNum,
			success: function(data, status, xhr) {
				buildTree(treeNum, [data.result]);
			}
		});
	}
	else {
		buildTree(treeNum, []);
	}
}

var updateTree = function(treeNum) {
	var prevTreeNum = _previousTreeNum(treeNum);
	var selected = $('#tree-'+prevTreeNum).jqxTree('val');
	if (selected == null) {
		return;
	}
	var expr = $('#tree-expression-box-'+treeNum).jqxInput('val');
	$.ajax({
		url: '/evaluate?node=' + selected.value + '&treenum=' + treeNum + '&expr=' + expr,
		success: function(data, status, xhr) {
			if (data.success) {
				$('#tree-'+treeNum).jqxTree('destroy');
				buildTree(treeNum, data.result);
			}
		}
	})
}

var _previousTreeNum = function(treeNum) {
	for (var i = 0; i < openedTrees.length; ++i) {
		if (openedTrees[i] == treeNum) {
			return openedTrees[i+1];
		}
	}
}

var buildTree = function(treeNum, roots) {
	var window = $('#tree-window-'+treeNum);
	var treeId = 'tree-' + treeNum;
	window.jqxPanel('append', $('<div class="tree" id="'+treeId+'"></div>'));
	var tree = $('#'+treeId);
	tree.jqxTree({
		theme: THEME,
		source: roots,
		width: 292,
		height: 566
	});
    tree.on('expand', function (event) {
        var $element = $(event.args.element);
        var loader = false;
        var loaderItem = null;
        var children = $element.find('ul:first').children();
        $.each(children, function () {
            var item = tree.jqxTree('getItem', this);
            if (item && item.id.startsWith('loading-')) {
                loaderItem = item;
                loader = true;
                return false
            };
        });
        if (loader) {
            $.ajax({
                url: '/children?node='+tree.jqxTree('getItem', event.args.element).value+'&treenum='+treeNum,
                success: function (data, status, xhr) {
                	tree.jqxTree('addTo', data.result, $element[0]);
                    tree.jqxTree('removeItem', loaderItem.element);
                }
            });
        }
    });
    tree.jqxTooltip({
    	trigger: 'click',
    	content: 'tootlip',
    	position: 'mouse'
    });
    tree.on('opening', function(event) {
    	var selected = tree.jqxTree('val');
    	$.ajax({
    		url: '/features?node='+selected.value,
    		success: function (data, status, xhr) {
    			var content;
    			if (data.result.length  == 0) {
    				content = '<span class="no-features">This element has no features</span>';
    			}
    			else {
    				content = '<table class="features">';
    				for (var i = 0; i < data.result.length; ++i) {
    					var feat = data.result[i];
    					content = content + '<tr><th class="feature-key">'+feat.key+'</th><td class="feature-value">'+feat.last+'</td></tr>';
    				}
    				content = content + '</table>';
    			}
    	    	tree.jqxTooltip('content', content);
            }
    	})
    });
}

var createButtons = function() {
	var tree = $('#btn-tree');
	tree.jqxButton({
		theme: THEME,
		width: 40
	});
	tree.on('click', function() {
		createTree();
	});

	var text = $('#btn-text');
	text.jqxButton({
		theme: THEME,
		width: 40
	});
	text.on('click', function() {
		createSections();
	});
}

$(document).ready(function () {
	createTree();
	createButtons();
});
