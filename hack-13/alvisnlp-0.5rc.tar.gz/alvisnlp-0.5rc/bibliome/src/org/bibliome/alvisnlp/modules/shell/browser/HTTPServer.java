/*
Copyright 2016 Institut National de la Recherche Agronomique

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package org.bibliome.alvisnlp.modules.shell.browser;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.transform.TransformerException;

import org.bibliome.alvisnlp.converters.expression.parser.ParseException;
import org.bibliome.util.Iterators;
import org.bibliome.util.Strings;
import org.bibliome.util.fragments.FragmentTag;
import org.bibliome.util.xml.XMLUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import alvisnlp.corpus.Annotation;
import alvisnlp.corpus.ArgumentElement;
import alvisnlp.corpus.Corpus;
import alvisnlp.corpus.Document;
import alvisnlp.corpus.DownCastElement;
import alvisnlp.corpus.Element;
import alvisnlp.corpus.ElementType;
import alvisnlp.corpus.ElementVisitor;
import alvisnlp.corpus.Layer;
import alvisnlp.corpus.Relation;
import alvisnlp.corpus.Section;
import alvisnlp.corpus.Tuple;
import alvisnlp.corpus.expressions.Evaluator;
import alvisnlp.corpus.expressions.ResolverException;
import fi.iki.elonen.NanoHTTPD;
import fi.iki.elonen.NanoHTTPD.Response.IStatus;
import fi.iki.elonen.NanoHTTPD.Response.Status;

class HTTPServer extends NanoHTTPD {
	private final Logger logger;
	private final Corpus corpus;
	private final Map<String,Element> elementIndex;
	private final Map<String,Layer> layerIndex;
	private final BrowserShellResolvedObjects resObj;
	
	public HTTPServer(int port, Logger logger, Corpus corpus, BrowserShellResolvedObjects resObj) {
		super(port);
		this.logger = logger;
		this.corpus = corpus;
		this.elementIndex = indexElements(corpus);
		this.layerIndex = indexLayers(corpus);
		this.resObj = resObj;
	}
	
	private static Map<String,Layer> indexLayers(Corpus corpus) {
		Map<String,Layer> result = new HashMap<String,Layer>();
		for (Document doc : Iterators.loop(corpus.documentIterator())) {
			for (Section sec : Iterators.loop(doc.sectionIterator())) {
				for (Layer layer : sec.getAllLayers()) {
					String id = Integer.toHexString(System.identityHashCode(layer));
					result.put(id, layer);
				}
			}
		}
		return result;
	}
	
	private static Map<String,Element> indexElements(Corpus corpus) {
		Map<String,Element> result = new HashMap<String,Element>();
		indexElement(corpus, result);
		for (Document doc : Iterators.loop(corpus.documentIterator())) {
			indexElement(doc, result);
			for (Section sec : Iterators.loop(doc.sectionIterator())) {
				indexElement(sec, result);
				for (Annotation a : sec.getAllAnnotations()) {
					indexElement(a, result);
				}
				for (Relation rel : sec.getAllRelations()) {
					indexElement(rel, result);
					for (Tuple t : rel.getTuples()) {
						indexElement(t, result);
					}
				}
			}
		}
		return result;
	}
	
	private static void indexElement(Element elt, Map<String,Element> map) {
		String id = elt.getStringId();
		map.put(id, elt);
	}
	
	@SuppressWarnings("unchecked")
	private static JSONObject jsonNode(String id, String html, String value, String icon, boolean addFakeChild) {
		JSONObject result = new JSONObject();
		result.put("id", id);
		result.put("html", html);
		result.put("value", value);
		result.put("icon", icon);
		if (addFakeChild) {
			JSONArray fakeChildren = new JSONArray();
			JSONObject fakeChild = jsonNode("loading-"+id, "Loading...", id, "/static/loading.png", false);
			fakeChildren.add(fakeChild);
			result.put("items", fakeChildren);
		}
		return result;
	}
	
	static String elementNodeIcon(Element elt) {
		elt = elt.getOriginal();
		ElementType type = elt.getType();
		return "/static/" + type.toString() + ".png";
	}
	
	JSONObject jsonElementNode(Element elt, String idPrefix, String treeNum) {
		String id = idPrefix + "-" + elt.getStringId() + "-" + treeNum;
		String html = resObj.getElementNodeLabel(elt);
		String value = elt.getStringId();
		String icon = elementNodeIcon(elt);
		return jsonNode(id, html, value, icon, true);
	}
	
	static JSONObject jsonLayerNode(Layer layer) {
		String id = Integer.toHexString(System.identityHashCode(layer));
		String name = layer.getName();
		return jsonNode("id-" + id, name, id, "/static/layer.png", true);
	}

	@SuppressWarnings("unchecked")
	JSONArray fillArray(Iterable<? extends Element> children, JSONArray array, String treeNum) {
		for (Element elt : children) {
			JSONObject jObj = jsonElementNode(elt, "id", treeNum);
			array.add(jObj);
		}
		return array;
	}

	JSONArray fillArray(Iterator<? extends Element> children, JSONArray array, String treeNum) {
		return fillArray(Iterators.loop(children), array, treeNum);
	}
	
	private JSONArray jsonElementChildren(Element elt, String treeNum) {
		return elt.accept(elementNodeChildrenVisitor, treeNum);
	}

	private ElementVisitor<JSONArray,String> elementNodeChildrenVisitor = new ElementVisitor<JSONArray,String>() {
		@Override
		public JSONArray visit(Annotation a, String param) {
			return new JSONArray();
		}

		@Override
		public JSONArray visit(Corpus corpus, String param) {
			return fillArray(corpus.documentIterator(), new JSONArray(), param);
		}

		@Override
		public JSONArray visit(Document doc, String param) {
			return fillArray(doc.sectionIterator(), new JSONArray(), param);
		}

		@Override
		public JSONArray visit(Relation rel, String param) {
			return fillArray(rel.getTuples(), new JSONArray(), param);
		}

		@SuppressWarnings("unchecked")
		@Override
		public JSONArray visit(Section sec, String param) {
			JSONArray result = new JSONArray();
			for (Layer layer : sec.getAllLayers()) {
				JSONObject jLayer = HTTPServer.jsonLayerNode(layer);
				result.add(jLayer);
			}
			fillArray(sec.getAllRelations(), result, param);
			return result;
		}

		@SuppressWarnings("unchecked")
		@Override
		public JSONArray visit(Tuple t, String param) {
			JSONArray result = new JSONArray();
			for (String role : t.getRoles()) {
				Element arg = t.getArgument(role);
				Element argElt = new ArgumentElement(t, role, arg);
				String idPrefix = "arg-" + t.getStringId();
				JSONObject jArg = jsonElementNode(argElt, idPrefix, param);
				result.add(jArg);
			}
			return result;
		}

		@Override
		public JSONArray visit(Element e, String param) {
			return e.getOriginal().accept(this, param);
		}
	};

	private JSONArray jsonLayerChildren(Layer layer, String treeNum) {
		return fillArray(layer, new JSONArray(), treeNum);
	}
	
	@SuppressWarnings("unchecked")
	private static JSONObject jsonElementFeature(Element elt, String key) {
		JSONObject result = new JSONObject();
		result.put("key", key);
		result.put("last", elt.getLastFeature(key));
		JSONArray jValues = new JSONArray();
		jValues.addAll(elt.getFeature(key));
		result.put("values", jValues);
		return result;
	}

	@SuppressWarnings("unchecked")
	private static JSONArray jsonElementFeatures(Element elt) {
		JSONArray result = new JSONArray();
		for (String key : elt.getFeatureKeys()) {
			result.add(jsonElementFeature(elt, key));
		}
		return result;
	}
	
	private JSONObject queryCorpus(String treeNum) {
		return jsonElementNode(corpus, "id", treeNum);
	}
	
	private JSONArray queryChildren(Collection<String> messages, String id, String treeNum) {
		if (elementIndex.containsKey(id)) {
			Element elt = elementIndex.get(id);
			return jsonElementChildren(elt, treeNum);
		}
		if (layerIndex.containsKey(id)) {
			Layer layer = layerIndex.get(id);
			return jsonLayerChildren(layer, treeNum);
		}
		messages.add("unknown node id: " + id);
		return new JSONArray();
	}
	
	private JSONArray queryFeatures(Collection<String> messages, String id) {
		if (elementIndex.containsKey(id)) {
			Element elt = elementIndex.get(id);
			return jsonElementFeatures(elt);
		}
		messages.add("unknown node id: " + id);
		return new JSONArray();
	}
	
	private JSONArray queryExpression(Collection<String> messages, String eltId, String exprStr, String treeNum) {
		try {
			Element elt;
			if (eltId == null || eltId.isEmpty()) {
				elt = corpus;
			}
			else {
				if (!elementIndex.containsKey(eltId)) {
					messages.add("unknown node id: " + eltId);
					return new JSONArray();
				}
				elt = elementIndex.get(eltId);
			}
			Evaluator eval = resObj.parseAndResolve(exprStr);
			return fillArray(eval.evaluateElements(resObj.getEvalCtx(), elt), new JSONArray(), treeNum);
		}
		catch (ResolverException|ParseException e) {
			messages.add(e.getMessage());
			return new JSONArray();
		}
	}

	@SuppressWarnings("unchecked")
	private JSONArray querySections(List<String> messages, String eltId, String layers, String filter) {
		if (!elementIndex.containsKey(eltId)) {
			messages.add("unknown node id: " + eltId);
			return new JSONArray();
		}
		try {
			Element elt = elementIndex.get(eltId);
			ElementType type = elt.getType();
			JSONArray result = new JSONArray();
			Collection<String> layerCollection = getLayerCollection(layers);
			Evaluator evalFilter = getEvalFilter(filter);
			switch (type) {
				case DOCUMENT: {
					Document doc = DownCastElement.toDocument(elt);
					for (Section section : Iterators.loop(doc.sectionIterator())) {
						JSONObject jSection = querySection(section, layerCollection, evalFilter);
						result.add(jSection);
					}
					break;
				}
				case SECTION: {
					Section section = DownCastElement.toSection(elt);
					JSONObject jObject = querySection(section, layerCollection, evalFilter);
					result.add(jObject);
					break;
				}
				default: {
					messages.add("element is neither a section or a document: " + eltId);
				}
			}
			return result;
		}
		catch (ResolverException|ParseException|TransformerException e) {
			messages.add(e.getMessage());
			return new JSONArray();
		}
	}
	
	private Evaluator getEvalFilter(String filter) throws ResolverException, ParseException {
		if (filter == null) {
			return null;
		}
		if (filter.isEmpty()) {
			return null;
		}
		return resObj.parseAndResolve(filter);
	}

	private static Collection<String> getLayerCollection(String layers) {
		if (layers == null) {
			return null;
		}
		if (layers.isEmpty()) {
			return null;
		}
		return Strings.splitAndTrim(layers, ',', 0);
	}
	
	@SuppressWarnings("unchecked")
	private JSONObject querySection(Section section, Collection<String> layers, Evaluator filter) throws TransformerException {
		Layer annotations = getAnnotations(section, layers);
		filterAnnotations(annotations, filter);
		HTMLBuilderFragmentTagIterator frit = new HTMLBuilderFragmentTagIterator(XMLUtils.docBuilder);
		FragmentTag.iterateFragments(frit, section.getContents(), annotations, 0);
		JSONObject result = new JSONObject();
		result.put("name", section.getName());
		String contents = frit.serialize();
		result.put("contents", contents);
		return result;
	}
	
	private static Layer getAnnotations(Section section, Collection<String> layers) {
		if (layers == null) {
			return section.getAllAnnotations();
		}
		Layer result = new Layer(section);
		for (String layerName : layers) {
			if (section.hasLayer(layerName)) {
				result.addAll(section.getLayer(layerName));
			}
		}
			return result;
	}
	
	private void filterAnnotations(Layer layer, Evaluator filter) {
		if (filter == null) {
			return;
		}
		Iterator<Annotation> it = layer.iterator();
		while (it.hasNext()) {
			Annotation a = it.next();
			if (!filter.evaluateBoolean(resObj.getEvalCtx(), a)) {
				it.remove();
			}
			}
	}
	
	private static final Pattern COMMAND = Pattern.compile("/(.*)[/]?");
	
	@SuppressWarnings("unchecked")
	private static Response jsonResponse(Object contents, Collection<String> messages) {
		JSONObject json = new JSONObject();
		JSONArray jMessages = new JSONArray();
		jMessages.addAll(messages);
		json.put("messages", jMessages);
		json.put("success", messages.isEmpty());
		json.put("result", contents);
		return newFixedLengthResponse(Status.OK, "application/json", json.toString());
	}
	
	private Response error(String path, IStatus status) {
		String descr = status.getDescription();
		logger.warning(path + ": " + descr);
		return newFixedLengthResponse(status, MIME_PLAINTEXT, descr);
	}

	private Response staticResponse(String path) {
		String resourceName = "/org/bibliome/alvisnlp/modules/shell/browser/files/" + path;
		logger.fine("resource = " + resourceName);
		InputStream is = HTTPServer.class.getResourceAsStream(resourceName);
		if (is == null) {
			return error(path, Status.NOT_FOUND);
		}
		String mimeType = getMimeTypeForFile(path);
		return newChunkedResponse(Status.OK, mimeType, is);
	}
	
	@Override
	public Response serve(IHTTPSession session) {
        Method method = session.getMethod();
        String uri = session.getUri();
        logger.fine("Request: " + method + " '" + uri + "'");

		Matcher m = COMMAND.matcher(uri);
		if (!m.matches()) {
			return error(uri, Status.NOT_FOUND);
		}
		String command = m.group(1);
		if (command.startsWith("static/")) {
			return staticResponse(command.substring(7));
		}
		Map<String,String> params = session.getParms();
		switch (command) {
			case "corpus": {
				List<String> messages = Collections.emptyList();
				String treeNum = params.get("treenum");
				return jsonResponse(queryCorpus(treeNum), messages);
			}
			case "children": {
				List<String> messages = new ArrayList<String>();
				String id = params.get("node");
				String treeNum = params.get("treenum");
				return jsonResponse(queryChildren(messages, id, treeNum), messages);
			}
			case "features": {
				List<String> messages = new ArrayList<String>();
				String id = params.get("node");
				return jsonResponse(queryFeatures(messages, id), messages);
			}
			case "evaluate": {
				List<String> messages = new ArrayList<String>();
				String eltId = params.get("node");
				String exprStr = params.get("expr");
				String treeNum = params.get("treenum");
				return jsonResponse(queryExpression(messages, eltId, exprStr, treeNum), messages);
			}
			case "sections": {
				List<String> messages = new ArrayList<String>();
				String eltId = params.get("node");
				String layers = params.get("layers");
				String filter = params.get("filter");
				return jsonResponse(querySections(messages, eltId, layers, filter), messages);
			}
			case "":
			case "index.html": {
				return staticResponse("index.html");
			}
			default: {
				return error(uri, Status.NOT_FOUND);
			}
		}
	}
}
