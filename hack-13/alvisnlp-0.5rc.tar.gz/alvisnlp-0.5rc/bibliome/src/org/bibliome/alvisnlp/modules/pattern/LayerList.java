/*
Copyright 2016 Institut National de la Recherche Agronomique

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package org.bibliome.alvisnlp.modules.pattern;

import java.util.AbstractList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import alvisnlp.corpus.Element;
import alvisnlp.corpus.Layer;

final class LayerList extends AbstractList<Element> {
	private final Layer layer;

	LayerList(Layer layer) {
		super();
		this.layer = layer;
	}

	@Override
	public Element get(int index) {
		return layer.get(index);
	}

	@Override
	public int size() {
		return layer.size();
	}
	
	static Collection<List<Element>> singleton(Layer layer) {
		List<Element> list = new LayerList(layer);
		return Collections.singleton(list);
	}
}