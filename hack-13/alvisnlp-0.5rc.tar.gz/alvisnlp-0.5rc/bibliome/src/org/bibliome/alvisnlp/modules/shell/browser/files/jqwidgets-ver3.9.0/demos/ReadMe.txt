Important:

To run a sample that includes data binding, you must open it via "http://..." protocol since Ajax makes http requests. 

Please, run any sample on a Localhost or Web Server. 
